var express = require("express");
var router = express.Router();
var passport = require("passport");

/* GET home page. GET route */
router.get("/", function (req, res, next) {
  // callback function that is triggered when the root URL of the application is requested
  res.render("index", { title: "Express" });
});

// Handle login POST
router.post(
  "/login",
  passport.authenticate("local", {
    successRedirect: "/dashboard",
    failRedirect: "/login",
    failureFlash: true,
  }),
);

module.exports = router;
